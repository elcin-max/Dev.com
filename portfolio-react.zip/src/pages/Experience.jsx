const Experience = () => {
  const jobs = [
    { year: "2024 - Present", role: "Blockchain Lead", company: "NPCI" },
    { year: "2023 - 2024", role: "Technical Lead", company: "HCL Tech" },
    { year: "2022 - 2023", role: "Senior Developer", company: "Rapid Innovations" },
    { year: "2018 - 2022", role: "Team Lead", company: "Simsol Technologies" },
    { year: "2017 - 2018", role: "Support Technician", company: "Impact Infotech" },
  ];

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <h2 className="text-3xl font-bold mb-6">Work Experience</h2>
      <div className="space-y-6">
        {jobs.map((job, idx) => (
          <div
            key={idx}
            className="bg-gray-900 p-4 rounded-lg shadow hover:scale-105 transition"
          >
            <h3 className="text-xl font-semibold">{job.role}</h3>
            <p className="text-gray-400">{job.company}</p>
            <p className="text-gray-500 text-sm">{job.year}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Experience;
