const Skills = () => {
  const skills = [
    "React", "Node.js", "MySQL", "Tailwind", "Docker", "Python",
    "Blockchain", "HTML", "CSS", "JavaScript"
  ];

  return (
    <div className="p-8 max-w-5xl mx-auto">
      <h2 className="text-3xl font-bold mb-6 text-center">My Skills</h2>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-6">
        {skills.map((skill, idx) => (
          <div
            key={idx}
            className="bg-gray-900 p-4 rounded-lg shadow flex items-center justify-center hover:scale-105 transition"
          >
            {skill}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Skills;
