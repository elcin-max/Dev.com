const Projects = () => {
  const projects = [
    {
      title: "Rust Blockchain App",
      description: "A high-performance blockchain solution using Rust.",
      image: "https://via.placeholder.com/300x200",
    },
    {
      title: "E-commerce Platform",
      description: "Full-stack online store with React & Node.js.",
      image: "https://via.placeholder.com/300x200",
    },
    {
      title: "School Management System",
      description: "Student fee and attendance management app.",
      image: "https://via.placeholder.com/300x200",
    },
  ];

  return (
    <div className="p-8 max-w-6xl mx-auto">
      <h2 className="text-3xl font-bold mb-6 text-center">Projects</h2>
      <div className="grid md:grid-cols-3 gap-6">
        {projects.map((project, idx) => (
          <div
            key={idx}
            className="bg-gray-900 p-4 rounded-lg shadow hover:scale-105 transition"
          >
            <img
              src={project.image}
              alt={project.title}
              className="rounded-lg mb-4"
            />
            <h3 className="text-xl font-semibold">{project.title}</h3>
            <p className="text-gray-400 text-sm">{project.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Projects;
