const About = () => {
  return (
    <div className="p-8 max-w-4xl mx-auto">
      <h2 className="text-3xl font-bold mb-6">About Me</h2>
      <div className="bg-gray-900 p-6 rounded-lg shadow">
        <p className="text-gray-300 leading-relaxed">
          Hi 👋 I'm Daniel, a passionate full-stack developer with a strong focus on
          React.js, Node.js, and MySQL. I love building scalable applications,
          creating smooth user experiences, and working on challenging projects.
        </p>
        <p className="mt-4 text-gray-400">
          Outside of coding, I enjoy learning new technologies, teaching, and
          contributing to open-source projects.
        </p>
      </div>
    </div>
  );
};

export default About;
