import { useState, useEffect } from "react";
import { ExternalLink, Github, Play, Star, Calendar, Users, Code, Zap, Award, TrendingUp, Eye, Heart, Filter, Search } from "lucide-react";

const Projects = () => {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [isVisible, setIsVisible] = useState(false);
  const [hoveredProject, setHoveredProject] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [featuredIndex, setFeaturedIndex] = useState(0);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  // Rotate featured projects
  useEffect(() => {
    const timer = setInterval(() => {
      setFeaturedIndex(prev => (prev + 1) % projects.filter(p => p.featured).length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const projects = [
    {
      id: 1,
      title: "Blockchain Payment Infrastructure",
      description: "High-performance payment processing system for India's digital infrastructure, handling millions of transactions daily with 99.99% uptime.",
      longDescription: "A comprehensive blockchain-based payment infrastructure built for NPCI, featuring advanced consensus mechanisms, real-time transaction processing, and regulatory compliance. The system processes over 10 million transactions daily across India.",
      image: "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=600&h=400&fit=crop",
      category: "blockchain",
      technologies: ["Rust", "Substrate", "WebAssembly", "PostgreSQL", "Docker", "Kubernetes"],
      status: "Production",
      featured: true,
      stats: { users: "50M+", transactions: "10M/day", uptime: "99.99%" },
      duration: "18 months",
      team: 12,
      links: {
        github: "#",
        live: "#",
        demo: "#"
      },
      achievements: [
        "Processed ₹2T+ in transactions",
        "Zero security incidents",
        "50% faster than previous system"
      ]
    },
    {
      id: 2,
      title: "DeFi Protocol Suite",
      description: "Decentralized finance platform with smart contracts for lending, borrowing, and yield farming on multiple blockchains.",
      longDescription: "A comprehensive DeFi ecosystem featuring automated market makers, lending protocols, and yield optimization strategies. Built with security-first approach and extensive testing.",
      image: "https://images.unsplash.com/photo-1639322537504-6427a16b0a28?w=600&h=400&fit=crop",
      category: "blockchain",
      technologies: ["Rust", "Solidity", "Web3.js", "React", "Node.js", "IPFS"],
      status: "Active",
      featured: true,
      stats: { tvl: "$50M+", apr: "12.5%", protocols: "5" },
      duration: "12 months",
      team: 8,
      links: {
        github: "#",
        live: "#",
        demo: "#"
      },
      achievements: [
        "$50M+ Total Value Locked",
        "5 integrated protocols",
        "12.5% average APY"
      ]
    },
    {
      id: 3,
      title: "Real-time IoT Data Platform",
      description: "Scalable IoT data processing platform built with Rust, handling sensor data from 10,000+ devices in real-time.",
      longDescription: "An industrial-grade IoT platform that collects, processes, and analyzes data from thousands of sensors in real-time. Features predictive analytics and automated alerting systems.",
      image: "https://images.unsplash.com/photo-1518432031352-d6fc5c10da5a?w=600&h=400&fit=crop",
      category: "systems",
      technologies: ["Rust", "InfluxDB", "Kafka", "Docker", "Grafana", "Prometheus"],
      status: "Production",
      featured: false,
      stats: { devices: "10K+", dataPoints: "1M/min", latency: "<10ms" },
      duration: "10 months",
      team: 6,
      links: {
        github: "#",
        live: "#"
      },
      achievements: [
        "10K+ connected devices",
        "Sub-10ms data processing",
        "99.95% system availability"
      ]
    },
    {
      id: 4,
      title: "E-commerce Microservices Platform",
      description: "Modern e-commerce platform with microservices architecture, serving millions of users with high availability.",
      longDescription: "A cloud-native e-commerce platform built with microservices architecture, featuring advanced caching, real-time inventory management, and personalized recommendation engine.",
      image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=600&h=400&fit=crop",
      category: "fullstack",
      technologies: ["React", "Node.js", "PostgreSQL", "Redis", "Docker", "AWS"],
      status: "Production",
      featured: true,
      stats: { users: "2M+", orders: "100K/month", revenue: "$5M+" },
      duration: "14 months",
      team: 10,
      links: {
        github: "#",
        live: "#",
        demo: "#"
      },
      achievements: [
        "2M+ active users",
        "$5M+ monthly revenue",
        "99.9% uptime achieved"
      ]
    },
    {
      id: 5,
      title: "School Management System",
      description: "Comprehensive school management solution with student tracking, fee management, and parent communication features.",
      longDescription: "A complete school management system handling student enrollment, attendance tracking, grade management, fee collection, and parent-teacher communication. Deployed across 50+ schools.",
      image: "https://images.unsplash.com/photo-1497486751825-1233686d5d80?w=600&h=400&fit=crop",
      category: "fullstack",
      technologies: ["React", "Node.js", "MySQL", "Express.js", "Tailwind CSS"],
      status: "Production",
      featured: false,
      stats: { schools: "50+", students: "25K+", teachers: "2K+" },
      duration: "8 months",
      team: 5,
      links: {
        github: "#",
        live: "#"
      },
      achievements: [
        "50+ schools deployed",
        "25K+ students managed",
        "95% user satisfaction"
      ]
    },
    {
      id: 6,
      title: "High-Performance Trading Engine",
      description: "Ultra-low latency trading engine for cryptocurrency exchanges, processing thousands of orders per second.",
      longDescription: "A high-frequency trading engine built with Rust for maximum performance and reliability. Features advanced order matching, risk management, and real-time market data processing.",
      image: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=600&h=400&fit=crop",
      category: "systems",
      technologies: ["Rust", "WebSocket", "Redis", "PostgreSQL", "Kafka", "Docker"],
      status: "Active",
      featured: false,
      stats: { latency: "<1ms", orders: "50K/sec", exchanges: "3" },
      duration: "6 months",
      team: 4,
      links: {
        github: "#",
        demo: "#"
      },
      achievements: [
        "Sub-millisecond latency",
        "50K+ orders per second",
        "Zero downtime deployment"
      ]
    }
  ];

  const categories = [
    { id: 'all', name: 'All Projects', icon: Code, color: 'from-gray-400 to-gray-600' },
    { id: 'blockchain', name: 'Blockchain', icon: Zap, color: 'from-purple-400 to-pink-500' },
    { id: 'systems', name: 'Systems', icon: Award, color: 'from-green-400 to-teal-500' },
    { id: 'fullstack', name: 'Full Stack', icon: TrendingUp, color: 'from-blue-400 to-cyan-500' }
  ];

  const filteredProjects = projects.filter(project => {
    const matchesCategory = selectedCategory === 'all' || project.category === selectedCategory;
    const matchesSearch = project.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         project.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         project.technologies.some(tech => tech.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  const featuredProjects = projects.filter(p => p.featured);

  const projectStats = {
    total: projects.length,
    inProduction: projects.filter(p => p.status === 'Production').length,
    technologies: [...new Set(projects.flatMap(p => p.technologies))].length,
    totalUsers: "52M+"
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-cyan-500 rounded-full mix-blend-multiply filter blur-xl animate-pulse"></div>
        <div className="absolute bottom-1/4 left-1/4 w-96 h-96 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl animate-pulse animation-delay-2000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-pink-500 rounded-full mix-blend-multiply filter blur-xl animate-pulse animation-delay-4000"></div>
      </div>

      <div className={`relative z-10 px-6 py-20 transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
        <div className="max-w-7xl mx-auto">
          
          {/* Header */}
          <div className="text-center mb-16">
            <h1 className="text-5xl lg:text-7xl font-bold mb-6 bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
              Projects
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              A showcase of innovative solutions spanning blockchain infrastructure, systems programming, and full-stack applications
            </p>
          </div>

          {/* Project Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
            <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10 text-center hover:border-cyan-400/50 transition-all duration-500 hover:scale-105">
              <Code className="w-8 h-8 text-cyan-400 mx-auto mb-3" />
              <div className="text-3xl font-bold text-white mb-1">{projectStats.total}</div>
              <div className="text-gray-400 text-sm">Total Projects</div>
            </div>
            <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10 text-center hover:border-green-400/50 transition-all duration-500 hover:scale-105">
              <Award className="w-8 h-8 text-green-400 mx-auto mb-3" />
              <div className="text-3xl font-bold text-white mb-1">{projectStats.inProduction}</div>
              <div className="text-gray-400 text-sm">In Production</div>
            </div>
            <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10 text-center hover:border-purple-400/50 transition-all duration-500 hover:scale-105">
              <Zap className="w-8 h-8 text-purple-400 mx-auto mb-3" />
              <div className="text-3xl font-bold text-white mb-1">{projectStats.technologies}</div>
              <div className="text-gray-400 text-sm">Technologies Used</div>
            </div>
            <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10 text-center hover:border-yellow-400/50 transition-all duration-500 hover:scale-105">
              <Users className="w-8 h-8 text-yellow-400 mx-auto mb-3" />
              <div className="text-3xl font-bold text-white mb-1">{projectStats.totalUsers}</div>
              <div className="text-gray-400 text-sm">Total Users Served</div>
            </div>
          </div>

          {/* Featured Projects Carousel */}
          <div className="mb-16">
            <h2 className="text-3xl font-bold mb-8 text-center">Featured Projects</h2>
            <div className="relative bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10">
              <div className="overflow-hidden">
                {featuredProjects.map((project, index) => (
                  <div
                    key={project.id}
                    className={`transition-all duration-500 ${
                      featuredIndex === index ? 'opacity-100 transform translate-x-0' : 'opacity-0 transform translate-x-full absolute top-0 left-0 w-full'
                    }`}
                  >
                    <div className="grid lg:grid-cols-2 gap-8 items-center">
                      <div>
                        <div className="flex items-center space-x-3 mb-4">
                          <span className="px-3 py-1 bg-gradient-to-r from-cyan-500/20 to-purple-500/20 border border-cyan-400/50 rounded-full text-cyan-400 text-sm font-medium">
                            Featured
                          </span>
                          <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                            project.status === 'Production' ? 'bg-green-500/20 text-green-400 border border-green-400/50' :
                            project.status === 'Active' ? 'bg-blue-500/20 text-blue-400 border border-blue-400/50' :
                            'bg-yellow-500/20 text-yellow-400 border border-yellow-400/50'
                          }`}>
                            {project.status}
                          </span>
                        </div>
                        <h3 className="text-2xl font-bold mb-4">{project.title}</h3>
                        <p className="text-gray-300 mb-6 leading-relaxed">{project.longDescription}</p>
                        
                        <div className="grid grid-cols-3 gap-4 mb-6">
                          {Object.entries(project.stats).map(([key, value], i) => (
                            <div key={i} className="text-center">
                              <div className="text-lg font-bold text-cyan-400">{value}</div>
                              <div className="text-xs text-gray-400 capitalize">{key.replace(/([A-Z])/g, ' $1')}</div>
                            </div>
                          ))}
                        </div>

                        <div className="flex space-x-3">
                          {project.links.live && (
                            <button className="px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-lg font-medium hover:from-cyan-400 hover:to-blue-400 transition-all duration-300 hover:scale-105 flex items-center space-x-2">
                              <ExternalLink className="w-4 h-4" />
                              <span>Live Demo</span>
                            </button>
                          )}
                          {project.links.github && (
                            <button className="px-4 py-2 bg-white/10 backdrop-blur-sm rounded-lg font-medium border border-white/20 hover:bg-white/20 transition-all duration-300 hover:scale-105 flex items-center space-x-2">
                              <Github className="w-4 h-4" />
                              <span>Code</span>
                            </button>
                          )}
                        </div>
                      </div>
                      
                      <div className="relative group">
                        <div className="absolute -inset-1 bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 rounded-xl blur opacity-75 group-hover:opacity-100 transition duration-1000 group-hover:duration-200 animate-pulse"></div>
                        <img
                          src={project.image}
                          alt={project.title}
                          className="relative w-full h-64 object-cover rounded-xl"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              
              {/* Carousel indicators */}
              <div className="flex justify-center space-x-2 mt-6">
                {featuredProjects.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setFeaturedIndex(index)}
                    className={`w-3 h-3 rounded-full transition-all duration-300 ${
                      featuredIndex === index ? 'bg-cyan-400 scale-125' : 'bg-gray-600 hover:bg-gray-400'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Filter and Search */}
          <div className="mb-12">
            <div className="flex flex-col lg:flex-row gap-6 items-center justify-between">
              {/* Category Filters */}
              <div className="flex flex-wrap gap-3">
                {categories.map((category) => {
                  const Icon = category.icon;
                  const isActive = selectedCategory === category.id;
                  return (
                    <button
                      key={category.id}
                      onClick={() => setSelectedCategory(category.id)}
                      className={`px-6 py-3 rounded-xl font-medium transition-all duration-300 flex items-center space-x-2 ${
                        isActive
                          ? `bg-gradient-to-r ${category.color} text-white shadow-lg scale-105`
                          : 'bg-white/5 text-gray-300 border border-white/10 hover:bg-white/10 hover:text-white hover:scale-105'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      <span>{category.name}</span>
                    </button>
                  );
                })}
              </div>

              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search projects..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-3 bg-white/10 backdrop-blur-sm rounded-xl border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-cyan-400/50 focus:border-cyan-400/50 transition-all duration-300"
                />
              </div>
            </div>
          </div>

          {/* Projects Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            {filteredProjects.map((project) => (
              <div
                key={project.id}
                onMouseEnter={() => setHoveredProject(project.id)}
                onMouseLeave={() => setHoveredProject(null)}
                className="bg-white/5 backdrop-blur-sm rounded-2xl overflow-hidden border border-white/10 hover:border-white/20 transition-all duration-500 hover:scale-105 group"
              >
                <div className="relative overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-48 object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                  <div className="absolute top-4 left-4 flex space-x-2">
                    <span className={`px-2 py-1 rounded text-xs font-medium ${
                      project.status === 'Production' ? 'bg-green-500/80 text-white' :
                      project.status === 'Active' ? 'bg-blue-500/80 text-white' :
                      'bg-yellow-500/80 text-white'
                    }`}>
                      {project.status}
                    </span>
                    {project.featured && (
                      <span className="px-2 py-1 bg-purple-500/80 text-white rounded text-xs font-medium">
                        Featured
                      </span>
                    )}
                  </div>
                  <div className="absolute bottom-4 left-4 right-4">
                    <h3 className="text-lg font-bold text-white mb-1">{project.title}</h3>
                  </div>
                </div>

                <div className="p-6">
                  <p className="text-gray-300 text-sm mb-4 leading-relaxed">{project.description}</p>
                  
                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.technologies.slice(0, 3).map((tech, i) => (
                      <span key={i} className="px-2 py-1 bg-white/10 backdrop-blur-sm rounded text-xs border border-white/20">
                        {tech}
                      </span>
                    ))}
                    {project.technologies.length > 3 && (
                      <span className="px-2 py-1 bg-white/10 backdrop-blur-sm rounded text-xs border border-white/20">
                        +{project.technologies.length - 3} more
                      </span>
                    )}
                  </div>

                  <div className="flex items-center justify-between text-sm text-gray-400 mb-4">
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-1">
                        <Calendar className="w-4 h-4" />
                        <span>{project.duration}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Users className="w-4 h-4" />
                        <span>{project.team}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex space-x-2">
                    {project.links.live && (
                      <button className="flex-1 px-3 py-2 bg-gradient-to-r from-cyan-500/20 to-blue-500/20 border border-cyan-400/50 rounded-lg text-cyan-400 font-medium hover:from-cyan-500/30 hover:to-blue-500/30 transition-all duration-300 flex items-center justify-center space-x-1">
                        <ExternalLink className="w-3 h-3" />
                        <span>Live</span>
                      </button>
                    )}
                    {project.links.github && (
                      <button className="flex-1 px-3 py-2 bg-white/10 backdrop-blur-sm border border-white/20 rounded-lg text-gray-300 font-medium hover:bg-white/20 transition-all duration-300 flex items-center justify-center space-x-1">
                        <Github className="w-3 h-3" />
                        <span>Code</span>
                      </button>
                    )}
                    {project.links.demo && (
                      <button className="flex-1 px-3 py-2 bg-purple-500/20 border border-purple-400/50 rounded-lg text-purple-400 font-medium hover:bg-purple-500/30 transition-all duration-300 flex items-center justify-center space-x-1">
                        <Play className="w-3 h-3" />
                        <span>Demo</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* No Results */}
          {filteredProjects.length === 0 && (
            <div className="text-center py-16">
              <div className="w-24 h-24 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <Search className="w-12 h-12 text-gray-400" />
              </div>
              <h3 className="text-xl font-semibold mb-2">No projects found</h3>
              <p className="text-gray-400 mb-6">Try adjusting your search or filter criteria</p>
              <button
                onClick={() => {
                  setSearchTerm('');
                  setSelectedCategory('all');
                }}
                className="px-6 py-3 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-xl font-semibold hover:from-cyan-400 hover:to-blue-400 transition-all duration-300 hover:scale-105"
              >
                Clear Filters
              </button>
            </div>
          )}

          {/* Call to Action */}
          <div className="text-center">
            <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10 max-w-4xl mx-auto">
              <h3 className="text-2xl font-bold mb-4">Interested in Collaborating?</h3>
              <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
                These projects represent just a portion of my work. I'm always excited to take on new challenges 
                and build innovative solutions that make a real impact.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button className="px-8 py-3 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl font-semibold hover:from-purple-400 hover:to-pink-400 transition-all duration-300 hover:scale-105">
                  Start a Project
                </button>
                <button className="px-8 py-3 bg-white/10 backdrop-blur-sm rounded-xl font-semibold border border-white/20 hover:bg-white/20 transition-all duration-300 hover:scale-105">
                  View More Work
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Projects;